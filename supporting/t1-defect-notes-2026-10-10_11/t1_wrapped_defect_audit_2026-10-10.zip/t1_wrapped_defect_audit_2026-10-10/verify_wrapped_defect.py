#!/usr/bin/env python3
"""Local charge/inflow/zero-mode tests for a NEW candidate wrapped defect.

The four-copy odd lattice is inherited as a candidate, not a globally established
quantum theory. The string-inflow rule is an explicit assumption. The proposed
2D fermions are a polynomial-matching construction, not a derived string spectrum.
No string tension, nonzero vacuum amplitude, ultraviolet completion or alpha
prediction is established by this script.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from pathlib import Path
import argparse
import json
import math
import sympy as s

R = s.Rational
checks: dict[str, bool] = {}

def eq(name: str, residual: object) -> None:
    if name in checks:
        raise ValueError(f'duplicate check: {name}')
    vals = list(residual) if isinstance(residual, s.MatrixBase) else [residual]
    reduced = [s.factor(s.expand(s.sympify(v))) for v in vals]
    checks[name] = all(v == 0 for v in reduced)
    if not checks[name]:
        raise AssertionError(f'{name}: {reduced}')

def test(name: str, statement: object) -> None:
    if name in checks:
        raise ValueError(f'duplicate check: {name}')
    checks[name] = bool(statement)
    if not checks[name]:
        raise AssertionError(name)

X, Z, p1, p2, C = s.symbols('X Z p1 p2 c2C')
pT, nP, nM = s.symbols('p1T c2Nplus c2Nminus')
Omega = s.diag(1, -1)
a = s.Matrix([3, 3])
vX = s.Matrix([-10, -9])
vZ = s.Matrix([-33, -42])
vC = s.Matrix([4, 4])
source = a*p1/4 + vX*X**2 + vZ*Z**2 + vC*C
P = X**2 - 9*Z**2
Q = R(19,8)*X**2 + R(75,8)*Z**2 - R(3,16)*p1 - C

def pair(q: s.Matrix, r: s.Matrix) -> s.Expr:
    return (q.T*Omega*r)[0]

eq('inherited_four_copy_factorization', pair(source, source)/2 - 4*P*Q)
eq('odd_pairing_unimodular', Omega.det()+1)
# Reconstruct all bulk fermion traces, not only the Abelian restriction.
c1,c2 = s.symbols('color_root_1 color_root_2')
color_roots = [c1,c2,-c1-c2]
C_roots = -(sum(z*z for z in color_roots))/2
bulk_fields = [
    ('Q',+1,True,2,1),('L',+1,False,2,-3),
    ('u',-1,True,1,4),('d',-1,True,1,-2),
    ('e',-1,False,1,-6),('spectator',+1,True,0,1)]
I8single=0
for name, chir, colored, x, z in bulk_fields:
    for root in color_roots if colored else [0]:
        w=x*X+z*Z+root
        I8single += chir*(w**4/24-p1*w*w/48+(7*p1*p1-4*p2)/5760)
eq('independent_bulk_Cartan_reconstruction',4*I8single-(4*P*Q).subs(C,C_roots))
eq('bulk_irreducible_gravitational_count',sum(ch*(3 if col else 1) for _,ch,col,_,_ in bulk_fields))

beta,gamma,phi1,phi2,alpha = s.symbols('beta gamma phi1 phi2 alpha', real=True)
phis = s.Matrix([phi1,phi2])
coordinate_map = {phi1:-beta/2-gamma,phi2:beta/2-gamma}
kX = 2*vX
qrho = s.Matrix([9,10])
qbeta4 = s.Matrix([-4,-4])
rho = gamma-R(19,2)*beta

eq('tensor_gauging_from_flux', kX-s.Matrix([-20,-18]))
eq('primitive_neutral_defect_charge', pair(qrho,kX))
test('neutral_defect_is_primitive',math.gcd(9,10)==1)
# -20 p+18 q=0 => 10 p=9 q. Coprimality implies (p,q)=m(9,10).
m=s.symbols('m',integer=True)
eq('general_neutral_integer_family',pair(m*qrho,kX))
eq('charge_character_is_rho',pair(qrho,phis).subs(coordinate_map)-rho)
eq('beta4_character',pair(qbeta4,phis).subs(coordinate_map)-4*beta)
eq('beta4_gauge_charge',pair(qbeta4,kX)-8)
eq('neutral_defect_norm',pair(qrho,qrho)+19)
eq('beta4_defect_is_null',pair(qbeta4,qbeta4))
eq('rho_gravitational_pairing',pair(qrho,a)+3)
eq('rho_X_pairing',pair(qrho,vX))
eq('rho_Z_pairing',pair(qrho,vZ)-123)
eq('rho_color_pairing',pair(qrho,vC)+4)
test('rho_characteristic_parity',(int(pair(qrho,qrho)-pair(qrho,a))%2)==0)
test('tensor_characters_integral',all(x.is_Integer for x in list(qrho.T*Omega)+list(qbeta4.T*Omega)))
# Source-shift/self-intersection derivation of the standard inflow rule.
D,chiN=s.symbols('delta4 chi4N')
inflow_expanded=s.expand(pair(source+qrho*D, source+qrho*D)/2-pair(source,source)/2)
eq('distributional_source_cross_term',inflow_expanded-pair(qrho,source)*D-pair(qrho,qrho)*D**2/2)
raw = pair(qrho,source)+pair(qrho,qrho)*(nP-nM)/2
I4rho=s.expand(raw.subs(p1,pT-2*(nP+nM)))
target=-R(3,4)*pT-8*nP+11*nM+123*Z**2-4*C
eq('rho_complete_required_worldsheet_polynomial',I4rho-target)
eq('beta4_required_polynomial',pair(qbeta4,source)-4*P)

@dataclass(frozen=True)
class Fermion:
    name: str
    copies: int
    chirality: int
    color_dim: int
    normal_plus_dim: int
    normal_minus_dim: int
    x: int
    z: int
    @property
    def dim(self) -> int:
        return self.color_dim*self.normal_plus_dim*self.normal_minus_dim

# ALL are X-neutral. Normal Spin(4) is NOT geometric weak SU(2).
ws = [
    Fermion('colored',4,+1,3,1,1,0,4),
    Fermion('abelian',6,+1,1,1,1,0,3),
    Fermion('normal_plus_triplet',2,+1,1,3,1,0,0),
    Fermion('normal_minus_quartet',1,-1,1,1,4,0,0),
    Fermion('normal_minus_doublet',1,-1,1,1,2,0,0),
]

def twice_index(dim: int) -> s.Expr:
    if dim < 1: raise ValueError('representation dimension must be positive')
    return R(dim*(dim*dim-1),6)

def anomaly(f: Fermion) -> s.Expr:
    if f.color_dim not in (1,3):
        raise ValueError('Only SU(3) singlet/fundamental supported')
    d=f.dim
    result=d*(f.x*X+f.z*Z)**2/2-d*pT/24
    if f.color_dim==3:
        result-=f.normal_plus_dim*f.normal_minus_dim*C
    result-=f.color_dim*f.normal_minus_dim*twice_index(f.normal_plus_dim)*nP
    result-=f.color_dim*f.normal_plus_dim*twice_index(f.normal_minus_dim)*nM
    return s.expand(f.copies*f.chirality*result)

I4ws=s.expand(sum(anomaly(f) for f in ws))
eq('explicit_2D_fermion_spectrum_matches_all_inflow',I4ws-target)
eq('normal_triplet_twice_Dynkin_index',twice_index(3)-4)
eq('normal_quartet_twice_Dynkin_index',twice_index(4)-10)
eq('normal_doublet_twice_Dynkin_index',twice_index(2)-1)
eq('worldsheet_signed_complex_dimension',sum(f.copies*f.chirality*f.dim for f in ws)-18)
eq('worldsheet_Z_charge_square_sum',sum(f.copies*f.chirality*f.dim*f.z*f.z for f in ws)-246)
eq('worldsheet_total_complex_components',sum(f.copies*f.dim for f in ws)-30)
eq('worldsheet_multiplet_count',sum(f.copies for f in ws)-14)
test('no_worldsheet_X_charged_fermions',all(f.x==0 for f in ws))

# Independent 2D Cartan-weight construction.
hp,hm=s.symbols('normal_plus_root normal_minus_root')
def su2_roots(dim: int, root: s.Symbol) -> list[s.Expr]:
    return [(dim-1-2*i)*root for i in range(dim)]
I4cartan=0
for f in ws:
    for cr in color_roots if f.color_dim==3 else [0]:
        for pr in su2_roots(f.normal_plus_dim,hp):
            for mr in su2_roots(f.normal_minus_dim,hm):
                w=f.x*X+f.z*Z+cr+pr+mr
                I4cartan+=f.copies*f.chirality*(w*w/2-pT/24)
eq('independent_2D_Cartan_weight_match',I4cartan-target.subs({C:C_roots,nP:-hp*hp,nM:-hm*hm}))
eq('worldsheet_mixed_Abelian_coefficient',I4ws.coeff(X).coeff(Z))

# Comparator: free worldsheet matching 4P for e^{4i beta}.
ws_beta=[Fermion('X_modes',2,+1,1,1,1,2,0),Fermion('Y_modes',2,-1,1,1,1,0,6)]
eq('electric_defect_free_fermion_comparator',sum(anomaly(f) for f in ws_beta)-4*P)
# On CP1, K^{1/2}=O(-1); dim H^0(O(n-1))=max(n,0),
# dim H^1(O(n-1))=max(-n,0). Opposite chirality exchanges kernel/cokernel.
def sphere_kernel_dimensions(n: int) -> tuple[int,int]:
    return max(n,0),max(-n,0)

def unlifted_grassmann_count(fields: list[Fermion], nX: int, nZ: int) -> int:
    return sum(f.copies*f.dim*sum(sphere_kernel_dimensions(f.x*nX+f.z*nZ)) for f in fields)

eq('electric_comparator_four_flux_zero_modes',unlifted_grassmann_count(ws_beta,1,0)-4)
eq('rho_candidate_zero_flux_for_every_fermion',sum(abs(f.x) for f in ws))
eq('rho_candidate_no_mandatory_fermion_zero_modes',unlifted_grassmann_count(ws,1,0))
eq('untwisted_spinor_no_kernel_or_cokernel',sum(sphere_kernel_dimensions(0)))
# Same anomaly polynomial does not force the same kernel: a massless vectorlike
# X-charged pair changes no anomaly but has two Grassmann zero-mode variables.
vectorlike_pair=[Fermion('extra_plus',1,+1,1,1,1,1,0),Fermion('extra_minus',1,-1,1,1,1,1,0)]
eq('anomaly_cancels_for_added_vectorlike_pair',sum(anomaly(f) for f in vectorlike_pair))
eq('same_anomaly_can_have_additional_zero_modes',unlifted_grassmann_count(ws+vectorlike_pair,1,0)-2)
# Counts do NOT include unspecified string-core fields. Flat normal, color, Z
# connections on the wrapped sphere are assumptions. This is not an index-only claim.
ell=s.symbols('ell',integer=True,nonnegative=True)
r,T=s.symbols('r T',positive=True)
lam2=(ell+1)**2/r**2
eq('untwisted_Dirac_spectral_gap',lam2.subs(ell,0)-1/r**2)
# A pure positive-tension Nambu-Goto probe has four translation zero modes;
# the spherical Laplacian controls its leading embedding fluctuations.
mu2=ell*(ell+1)/r**2
eq('probe_translation_mass_zero',mu2.subs(ell,0))
eq('first_probe_embedding_nonzero_mass',mu2.subs(ell,1)-2/r**2)
# Elementary local graph-area expansion (two worldsheet dimensions).
e,a11,a12,a22=s.symbols('e a11 a12 a22',real=True)
graph=s.Matrix([[1+e*e*a11,e*e*a12],[e*e*a12,1+e*e*a22]])
area_series=s.series(s.sqrt(graph.det()),e,0,4).removeO()
eq('probe_area_positive_gradient_quadratic_form',area_series-1-e*e*(a11+a22)/2)
eq('wrapped_probe_area_action',s.diff(4*s.pi*r*r*T,T)-4*s.pi*r*r)

# A potential is CONDITIONAL: its coefficient is not computed here.
u,rhop=s.symbols('u rho',real=True)
chi,A=s.symbols('chiC Adefect',positive=True)
V=chi*(1-s.cos(4*u))+A*(1-s.cos(rhop))
H=s.hessian(V,(u,rhop)).subs({u:0,rhop:0})
eq('two_phase_conditional_Hessian',H-s.diag(16*chi,A))
eq('two_phase_conditional_determinant',H.det()-16*chi*A)
eq('no_defect_returns_one_flat_phase',H.subs(A,0).det())
eq('conditional_potential_lattice_index',s.diag(4,1).det()-4)
# Alternative field redefinition consistency: rho's intrinsic defect contains
# no new phase analogous to thetaSigma; adding a separate charged scalar did.
test('neutral_defect_not_a_beta_only_character',qrho[0]!=qrho[1])

out={
 'date':'2026-10-10',
 'status':'LOCAL ALGEBRA AND SPECIFIED FREE WORLD-SHEET ZERO-MODE TESTS PASS; NOT A MICROSCOPIC STRING OR VACUUM AMPLITUDE',
 'sympy_version':s.__version__, 'checks_count':len(checks), 'checks':checks,
 'inherited_candidate':'four copied repaired fermion blocks; odd I_(1,1) lattice; NOT the failed one-copy model',
 'charge_basis_convention':'character exp(i q^T diag(1,-1) phi), phi_i periods 2pi',
 'rho_charge':[9,10], 'rho_character':'9 phi1 - 10 phi2 = gamma - 19 beta/2',
 'rho_pairings':{'norm':-19,'a':-3,'vX':0,'vZ':123,'vC':-4},
 'adopted_inflow_rule':'I4_required=q.S4+(q.q)/2 e(N); convention as in cited standard string-inflow formula',
 'required_worldsheet_polynomial':str(target),
 'worldsheet_proposed_fermions':[asdict(f) for f in ws],
 'worldsheet_component_counts':{'positive_chirality':24,'negative_chirality':6,'total':30},
 'fermion_zero_modes_in_proposed_sector_on_reference_sphere':0,
 'electric_beta4_comparator_fermion_zero_modes':4,
 'no_zero_mode_assumptions':['round S2 at a point of Euclidean flat M4','unit X flux; zero Z/color flux','trivial flat normal connection','ordinary untwisted worldsheet spinors; no added twists','no unspecified core fields included'],
 'negative_claims':{
  'microscopic_dynamical_string_constructed':False,
  'global_spin_refined_counterterm_constructed':False,
  'worldsheet_interactions_from_bulk_derived':False,
  'backreacted_defect_solution_obtained':False,
  'defect_tension_or_full_prefactor_computed':False,
  'nonzero_bosonic_vacuum_amplitude_proved':False,
  'alpha_predicted':False},
 'important_cautions':['The required worldsheet polynomial and table are not assumptions of supersymmetry. No BPS/critical-string bounds are imported.',
  'Odd lattice refinements, possible global anomalies and operator statistics remain unresolved.',
  'Adding vectorlike X-charged pairs leaves I4 unchanged but can introduce extra sphere zero modes.',
  'Probe graph-area check is not a solution of sourced tensor or Einstein equations.',
  'An allowed lattice charge is not evidence of a dynamical defect with that charge.']}
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('wrapped_defect_results.json'))
args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(out,indent=2)+'\n')
print(f'{len(checks)} exact checks passed.')
print('Primitive X-neutral candidate tensor charge: (9,10), phase rho.')
print('Required local worldsheet anomaly matched by 14 proposed multiplets / 30 complex Weyl components.')
print('Specified X-neutral free worldsheet sector: no fermion kernel on reference S2.')
print('No microscopic string, global quantum completion, or physical vacuum amplitude established.')
