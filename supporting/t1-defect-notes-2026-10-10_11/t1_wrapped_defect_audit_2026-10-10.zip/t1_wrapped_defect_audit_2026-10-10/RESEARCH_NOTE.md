# T-1 comparison branch: wrapped-defect charge, inflow, and zero-mode audit

**Date:** 2026-10-10  
**Status:** A local, conditional defect effective-field-theory construction. Not a microscopic dynamical string, global quantum completion, or calculation of a nonzero potential.  
**Continuation input:** `t1_uv_mediator_matching_2026-10-10.zip`.

## Executive result

The inherited FOUR-COPY odd-lattice candidate contains a unique primitive tensor charge neutral under the flux-induced U(1)_X gauging, up to orientation: q_rho=(9,10). Its surface character is exp[i(gamma-19 beta/2)] = exp(i rho). This is different from the electric exp(4 i beta) dressing of the preceding proposed mediator bilinear. The electric dressing carries X charge and cannot supply a pure vacuum term by itself. The neutral character suggests a distinct defect channel for the remaining phase.

Adopting the standard bilinear string-inflow rule, the required local worldsheet polynomial for q_rho is

    I4_required = -3 p1(TSigma)/4 -8 c2(N+) +11 c2(N-)
                  +123 Z^2 -4 c2(C).

Here N+ and N- are the two Spin(4) normal-rotation factors, NOT the geometric weak SU(2). A NEW, explicitly proposed set of 14 multiplets, containing 30 complex two-dimensional Weyl components, matches this polynomial. Every proposed worldsheet fermion is neutral under X. With flat normal/color/Z connections on the reference wrapped sphere, their Dirac operators have no kernel. This eliminates a particular flux-forced zero-mode obstruction in this stipulated sector, but proves neither that this string exists nor that it contributes a bosonic term to the full partition function.

A positive-tension probe would have an area contribution 4 pi r^2 T_rho to its Euclidean action. T_rho, its core, nonzero-mode determinant, global refinements, possible extra fields and interactions, and the full sourced background have not been constructed. No value, or established nonzero value, of the resulting potential coefficient is supplied.

## 1. Provenance and what was actually run

The input ZIP is preserved without modification in `baseline/`. Its SHA-256 is recorded in `PROVENANCE.json`. The preceding archive was inspected before its scripts were executed. A fresh run of its symbolic script passed 54 checks; a fresh run of its numerical radial-kernel script passed 9 checks. These logs and their new output files are included. Earlier nested baselines were not all rerun in this step.

The new `verify_wrapped_defect.py` passes 50 exact checks. They include reconstruction of the inherited bulk fermion anomaly from formal SU(3) Cartan roots; the charge-character map; the neutral integer kernel; the defect source pairings; two independent reconstructions of the proposed worldsheet anomaly; and conditional phase-Hessian identities. The zero-mode checks use the stated exact spin-sphere spectrum/cohomology formulas. They are not a numerical PDE solution or proof of a complete string path integral.

Source distinction: the uploaded corpus's September claim-by-claim change log, Part 1 of 4, states that the illustrative compactification is not the corpus's own action (displayed lines 549-558) and calls T-1 a gated geometric candidate, not a derived measured coupling (lines 64-78). These new defect hypotheses are separate from that monograph. No repository or Zenodo record was modified.

## 2. Inherited lattice conventions

We retain the four-copy candidate, not the one-copy theory whose integral-lattice test failed. Let

    Omega = diag(1,-1),
    a = (3,3),
    vX = (-10,-9),
    vZ = (-33,-42),
    vC = (4,4).

The source vector is

    S4 = a p1(T6)/4 + vX X^2 + vZ Z^2 + vC c2(C).

X and Z are normalized integral U(1) curvatures. Z=Y/3 corresponds to integral charge z=3y; the earlier doubled hypercharge convention was electric charge T3+y/2. The inherited polynomial obeys

    I8^(4) = (1/2) S4^T Omega S4 = 4 P4 Q4,
    P4 = X^2 -9 Z^2,
    Q4 = (19/8)X^2 +(75/8)Z^2 -(3/16)p1(T6) -c2(C).

This identity was independently reconstructed from four copies of

    Q+:(3,x=2,z=1), L+:(1,2,-3), u-:(3,1,4),
    d-:(3,1,-2), e-:(1,1,-6), spectator+:(3,0,1).

The subscripts specify bulk chirality. The geometric weak group is not an independent six-dimensional Yang-Mills factor here.

The candidate tensor angles, each of period 2 pi, are

    phi1 = -beta/2 -gamma,
    phi2 = +beta/2 -gamma.

Under X gauge parameter alpha,

    Delta(phi1,phi2)=(-20,-18) alpha = 2 vX alpha.

The bilinear charge pairing is q.r=q^T Omega r. A surface character is written

    exp(i q^T Omega phi).

This fixes the distinction between a lattice vector q and the coordinate covector appearing in an exponent. Omega is a charge pairing, not a kinetic-energy metric. Its indefinite signature alone neither makes a state a ghost nor proves the existence of positive-tension states of a specified charge. Charge quantization and odd/even tensor lattices are discussed in Seiberg and Taylor [1].

## 3. Primitive neutral charge and the electric comparison

A string wrapping the internal sphere has an X-gauge variation proportional to

    q.(2 vX) = -20 q1 +18 q2.

A pure tensor character is X neutral precisely when 10 q1=9 q2. Coprimality gives

    q=m(9,10), m integer.

The primitive charge is therefore q_rho=(9,10), up to orientation. Its character is

    q_rho.Omega.phi = 9 phi1 -10 phi2 = gamma-19 beta/2 = rho.

Its lattice data are

    q_rho^2=-19, q_rho.a=-3,
    q_rho.vX=0, q_rho.vZ=123, q_rho.vC=-4.

The characteristic parity check q^2 = q.a mod 2 passes. This is not the missing global spin-refinement theorem; it is only one arithmetic compatibility test.

By contrast, the electric dressing exp(4 i beta) has q_beta4=(-4,-4). It has q_beta4^2=0 and X charge +8. Therefore it needs an insertion of X charge -8, such as the formal ST bilinear of the last comparison. It cannot provide a gauge-invariant pure vacuum term by itself.

Allowed lattice charge does not mean an established dynamical defect. No completeness or Weak Gravity Conjecture assumption is used to infer that a charge-(9,10) string is present.

## 4. Inflow requirement

We adopt the usual local string-inflow convention in which the required worldsheet polynomial is

    I4(q) = q.S4 + (q.q)/2 e4(N).

The bulk inflow has the compensating anomaly. Reversing orientation/conventions must change the corresponding worldsheet chirality convention consistently. This is the bilinear source and self-intersection formula illustrated in Shimizu and Tachikawa [2]. Their detailed applications are supersymmetric; we use the source-inflow rule, not their BPS spectra, central-charge formulas, or positivity bounds.

A formal derivation of the local terms is to substitute S4+q delta4(Sigma) into (1/2)S4.S4. The terms supported on Sigma are

    (q.S4) delta4 + (q.q)/2 delta4^2.

Using the Thom self-intersection identity delta4^2=e4(N) delta4 gives the displayed four-form. This is a local/topological inflow calculation, not a construction of the global differential cocycles.

For a spin normal bundle of rank four, choose conventions

    e4(N)=c2(N+)-c2(N-),
    p1(N)=-2[c2(N+)+c2(N-)],
    p1(T6)|Sigma=p1(TSigma)+p1(N).

For q_rho, this yields

    I4(q_rho)
      = -(3/4)p1(TSigma) -8 c2(N+) +11 c2(N-)
        +123 Z^2 -4 c2(C).

The normal Euler term is essential: q_rho^2/2=-19/2. It is not legitimate to drop it simply because the normal connection is flat in the single reference background. Anomaly matching concerns general background curvatures.

For q_beta4, the gravitational and self-intersection coefficients vanish and

    I4(q_beta4)=4P4=4X^2-36Z^2.

## 5. NEW candidate worldsheet matter

This is an explicitly added defect-EFT hypothesis. These are two-dimensional fields on the string, not newly derived six-dimensional bulk multiplets or additional four-dimensional generations. We specify complex Weyl fermions with chirality sign s=+1 contributing [Ahat(TSigma) ch(F)]_4. With the opposite overall anomaly convention all signs must be changed consistently.

| multiplicity | chirality | SU(3)_C | SU(2)_N+ | SU(2)_N- | x | z |
|---:|:---:|:---:|:---:|:---:|---:|---:|
| 4 | + | 3 | 1 | 1 | 0 | 4 |
| 6 | + | 1 | 1 | 1 | 0 | 3 |
| 2 | + | 1 | 3 | 1 | 0 | 0 |
| 1 | - | 1 | 1 | 4 | 0 | 0 |
| 1 | - | 1 | 1 | 2 | 0 | 0 |

**The two normal SU(2)s rotate the four directions transverse to the string. They are not the weak sphere-isometry SU(2).**

For a complex two-dimensional Weyl fermion of charge z and total representation dimension d, the Abelian/gravitational part is

    s [ d z^2 Z^2/2 - d p1(TSigma)/24 ],

with the non-Abelian ch2 terms included. The fundamental SU(3) contributes -c2(C). The n-dimensional SU(2) representation contributes

    -[n(n^2-1)/6] c2(SU2).

These are direct Chern-character formulas, with the worldsheet convention reviewed in [2].

The color-charged row gives -4c2(C). Its Z coefficient is 4*3*4^2/2=96. The six singlets add 6*3^2/2=27, producing 123. The two positive normal triplets produce -2*4 c2(N+)=-8 c2(N+). The negative normal quartet and doublet produce (10+1)c2(N-). Finally,

    signed dimension =12+6+6-4-2=18,

so the tangent gravitational coefficient is -18/24=-3/4. The full polynomial matches I4(q_rho) exactly. There are 24 positive and 6 negative complex Weyl components, 30 total in 14 multiplets.

This check does not prove worldsheet modular consistency, global anomalies, the target-space spin refinement, stability of an interacting string core, or an ultraviolet completion. We have not asserted a critical fundamental string or imposed a critical-string central-charge condition. It is a chiral matter construction on an effective surface with an induced metric. Extra nonchiral embedding fields do not change the local polynomial but do affect determinants and dynamics.

## 6. Wrapped-sphere zero modes

For this test ONLY, take the reference geometry Euclidean R^4 times a round S^2, with the sphere embedded at a point of R^4. The normal bundle and its connection are trivial. Assume unit X flux, no internal color or Z flux, no extra worldsheet twisting, and the displayed free massless worldsheet kinetic operators.

A charged spinor on S^2 couples to a line bundle of degree n=x N_X+z N_Z. The spin bundle K^(1/2) is O(-1). The holomorphic description gives

    dim H^0(O(n-1))=max(n,0),
    dim H^1(O(n-1))=max(-n,0).

The monopole Dirac kernel and its representation content are discussed in Jante and Schroers [3]. The ordinary untwisted Dirac spectrum is [4]

    lambda_l = plus/minus (l+1)/r, l=0,1,... .

For every field in the q_rho table, x=0 and N_Z=0, while the color and normal connections are flat. Thus n=0 for every component and there are no fermion zero modes in this STIPULATED sector. This conclusion uses an actual kernel/vanishing result, not the invalid inference 'index zero implies no zero modes.'

A minimal free comparator for q_beta4 consists of two positive complex Weyl fermions with (x,z)=(2,0) and two negative ones with (x,z)=(0,6). Their polynomial is 4P4 with zero net gravitational anomaly. In unit X flux, the two charge-2 fields give four Grassmann kernel variables. The free uninserted determinant vanishes. Appropriate charged insertions and worldsheet interactions would be needed to saturate them; the anomaly alone does not give those interactions.

Conversely, matching I4(q_rho) does not FORCE absence of zero modes. Adding a massless vectorlike pair of X-charge 1 changes no anomaly polynomial but adds two Grassmann zero-mode variables on the sphere. A permitted mass could lift that pair, but no such extra pair or mass is part of our specified table. This explicitly illustrates why an anomaly polynomial is not a complete worldsheet theory.

The result is limited to the uncondensed product reference background. The previously calculated Higgs-induced internal hypercharge dipole, additional twists, interactions, and sourced-defect fields can change the spectral problem. They are not silently set equal to this free result.

## 7. A surface action and what its area term would mean

A probe defect can be parameterized schematically by

    S_E,Sigma = T_q integral_Sigma sqrt(gamma)
                - i q.Omega integral_Sigma B
                + S_worldsheet_fermions + S_extra,

normalizing the holonomy so that its phase is exp(i q.Omega phi). On the once-wrapped reference sphere, the displayed classical area term is

    S_area=4 pi r^2 T_rho.

A scalar surface contribution, IF globally defined, present in the dynamical sum, and with nonvanishing determinants, would have schematic weight

    C_rho exp(-4 pi r^2 T_rho) exp(i rho).

C_rho is not computed; after the external position integral is separated its effective potential coefficient has mass dimension four. T_rho is not fixed by the charge norm. A lattice pairing is not a tension formula.

For a positive-tension, fixed-product Nambu-Goto probe, the four transverse embedding fields have positive gradient quadratic action, with l=0 translation modes and l>=1 spherical Laplacian eigenvalues l(l+1)/r^2. This limited check does not solve the tensor or Einstein equations in the presence of the actual charged source. In particular, a string core and bulk-field self-energy cannot be replaced by the area term alone.

No determinant zero modes are forced by the specified free fermion table, but this is only one prerequisite. We have not derived additional core/collective fields, the spin-dependent sign of the surface amplitude, whether the primitive character can occur as a bosonic insertion in the full refined theory, a tension, a determinant normalization, a sourced solution, or the sum over wrapped defects. The odd-lattice global counterterm and defect consistency are precisely the additional issues emphasized in [5].

## 8. Consequence for the phase problem, conditional on a genuine amplitude

If the completed dynamics did generate a bosonic primitive contribution with curvature A_rho>0 at its minimum, a local test potential would be

    V = E_C(theta_const-4u) + A_rho [1-cos(rho+theta_rho)].

At a simultaneous minimum, with color curvature chi_C>0,

    Hessian_(u,rho) = diag(16 chi_C,A_rho).

For positive kinetic matrix K, the product of the two squared masses is

    det(K^-1 Hessian)=16 chi_C A_rho/det(K).

This tests two independent phase directions; it does not compute A_rho. If global selection rules allow only a higher harmonic, the Hessian and vacuum count must be recomputed accordingly. With only the primitive rho harmonic and color harmonic 4u, the character lattice index is four; no uniqueness-of-vacuum claim is made.

This route would not need the tensor-dressed QQQL interaction of the earlier WEAK-INSTANTON channel. That does not contradict the prior baryon/lepton selection rule, which applied to that channel. It postulates a different charged-defect sector. It does not realize the forbidden simple bulk SQQ and TQL vertices and does not compute their matching coefficient.

Unlike replacing the dressing by a new elementary scalar Sigma, this surface character uses an existing tensor phase and does not by definition add a new light scalar phase. Actual defect internal fields could change the low-energy spectrum, so the absence of such fields must not be asserted without constructing the defect dynamics.

## 9. Bounded conclusions

Established by this audit: the primitive neutral integer charge, its full local inflow requirement, one explicit matching 2D fermion spectrum, and its absence of flux-forced fermion zero modes on the specified reference sphere. These are useful necessary-consistency and candidate-construction results.

Not established: a dynamical ultraviolet string, a globally refined bosonic surface insertion, a full interacting worldsheet, a sourced six-dimensional solution, a nonzero wrapped-string amplitude, a physical phase mass, or a realistic particle theory. The one-copy integral-lattice obstruction is unchanged. The four-copy candidate is still a comparison model.

No value of the fine-structure constant was used, and no gauge kinetic normalization has been fixed. The user's corpus classifies T-1 as a geometric candidate rather than a derived measured coupling; this audit supplies no basis to alter that classification.

## References and scope

[1] N. Seiberg and W. Taylor, *Charge Lattices and Consistency of 6D Supergravity*, arXiv:1103.0019. https://arxiv.org/html/1103.0019 . Used for tensor charge pairings, odd/even lattices, and the distinction between charge pairing and dynamical data.

[2] H. Shimizu and Y. Tachikawa, *Anomaly of strings of 6d N=(1,0) theories*, arXiv:1608.05894. https://arxiv.org/html/1608.05894 . Equations (5)-(11) for bilinear string inflow and normal-bundle self-intersection; worldsheet Weyl-fermion anomaly convention in section 2.2. The specific supersymmetric dynamics are NOT imported into our nonsupersymmetric trial.

[3] R. Jante and B. J. Schroers, *Dirac operators on the Taub-NUT space, monopoles and SU(2) representations*, arXiv:1312.4879. https://arxiv.org/html/1312.4879 . Section 2 for twisted sphere spinors, kernel counting and holomorphic sections.

[4] R. Camporesi and A. Higuchi, *On the eigenfunctions of the Dirac operator on spheres and real hyperbolic spaces*, arXiv:gr-qc/9505009. https://arxiv.org/html/gr-qc/9505009 . Used for the untwisted Dirac spectral gap, not a computation of our full defect determinant.

[5] S. Monnier and G. W. Moore, *Remarks on the Green-Schwarz terms of six-dimensional supergravity theories*, arXiv:1808.01334. https://arxiv.org/html/1808.01334 . Used for the distinction between local factorization, global spin/Wu refinements and assumed defect anomaly cancellation. Its full theorems have NOT been shown to apply to the present trial.

[6] User-provided *MQGT-SCF / Theory of Everything — claim-by-claim change log*, research snapshot September 19, 2026, in Part 1 of 4: displayed lines 64-78 and 549-558. Used only for the corpus's own status and separation of illustrative compactifications. No claim to independently rerun the full corpus.
