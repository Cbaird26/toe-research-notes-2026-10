# Wrapped-defect audit: FOUR-COPY comparison only

Read `RESEARCH_NOTE.md` for assumptions, sign conventions, new field content, and limitations.

Run the new local algebra with:

```sh
python -m pip install -r requirements.txt
python verify_wrapped_defect.py
```

It writes `wrapped_defect_results.json`. An optional `--output PATH` changes the output file. A failed assertion stops the run.

The input mediator archive is preserved in `baseline/`. Fresh rerun logs/results of its 54-check symbolic script and 9-check numerical script are included. This step did not rerun every older nested baseline.

**Not a claimed ultraviolet completion.** The new construction matches a local string-inflow polynomial and tests a chosen free worldsheet spectrum on a fixed reference sphere. It does not establish that the string is dynamical, its amplitude is nonzero, the odd-lattice spin refinement exists, or the electromagnetic coupling is predicted.

`PROVENANCE.json` and `SHA256SUMS.json` record file provenance and hashes. No repository or Zenodo upload was performed.
