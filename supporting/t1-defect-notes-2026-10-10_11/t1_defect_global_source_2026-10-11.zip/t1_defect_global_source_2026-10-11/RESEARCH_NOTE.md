# Charge-(9,10) defect: lifted global anomaly, smooth-source obstruction, and regulated exterior

**Date:** 2026-10-11  
**Branch:** the exploratory four-copy odd-tensor-lattice sphere model, not the original toroidal MQGT-SCF action.  
**Status:** conditional mathematical results. No microscopic string, resolved core, full six-dimensional global path integral, or nonzero vacuum amplitude is established.

## Executive result

The proposed worldsheet fermions admit a globally defined inverse anomaly theory on a specifically lifted background category: a chosen worldsheet spin structure, a compatible independent Spin(4) normal lift, and the direct-product gauge group. The relevant degree-three spin bordism group vanishes. This does NOT prove that the inherited six-dimensional tensor theory supplies that inverse anomaly theory or that the surface insertion descends without those extra spin data.

A separate source calculation rules out obtaining the primitive charge (9,10) from a smooth, localized gauge-instanton core of the already specified fields with transverse R4 compactifying to S4. The two components of any such induced tensor charge are equal, whereas the desired charge has component difference -1. On closed spin four-manifolds the displayed smooth characteristic sources give even component differences; the primitive charge is again outside that smooth-source class. This does not forbid a fundamental charged string or additional topology/sources.

The zero-mode test can also be strengthened. A smooth Abelian connection of total degree zero on a genus-zero surface cannot create a kernel for the minimally coupled spin Dirac operator in this line-bundle sector. Thus the previously found hypercharge dipole, by itself and with the color and normal connections still trivial, does not invalidate the proposed free-fermion no-kernel result.

Finally, the low-energy point insertion exp(i rho) has a calculable exterior Gaussian solution and a positive regulated dual-flux action proportional to the inverse square matching radius. It determines a tail, not a core fugacity. It must not be extrapolated beneath the effective-theory cutoff.

## 1. Provenance and inherited data

Input archive: `t1_wrapped_defect_audit_2026-10-10.zip`. Its verification script was inspected and rerun with fresh output. The 50 existing finite algebra checks pass. This note's script performs 54 finite algebra checks. The checks are not independent empirical tests and do not machine-prove the external topology theorems used as input.

The inherited odd pairing is

    Omega = diag(1,-1),
    q = (9,10),
    a = (3,3),
    vX = (-10,-9),
    vZ = (-33,-42),
    vC = (4,4).

The lattice-valued four-form is

    S4 = (a/4) p1(T6) + vX X^2 + vZ Z^2 + vC c2(C).

X and Z are integral first-Chern-class normalized curvatures for the stated covering gauge group. In particular z=3y and Z=Y/3 relative to earlier fractional hypercharge notation. Products of characteristic forms are wedge/cup products as appropriate.

The candidate tensor angles are

    phi1 = -beta/2 - gamma,
    phi2 =  beta/2 - gamma,

with individual periods 2 pi. Their X-gauging vector is 2vX=(-20,-18). The character of q is

    q^T Omega phi = 9 phi1 - 10 phi2 = gamma - 19 beta/2 = rho.

It is X-neutral, since q^T Omega (2vX)=0, although q itself is NOT zero tensor charge. Neutrality under an ordinary vector gauge group does not remove the tensor Gauss-law source.

The inherited inflow convention requires

    I4(q) = q.S4 + (q.q)/2 e4(N).

With e4(N)=c2(N+)-c2(N-), p1(N)=-2[c2(N+)+c2(N-)], the primitive charge requires

    I4rho = -3 p1(TSigma)/4 - 8 c2(N+) + 11 c2(N-)
            + 123 Z^2 - 4 c2(C).

This follows from q.q=-19, q.a=-3, q.vX=0, q.vZ=123, q.vC=-4. The inflow structure is standard [1]; no supersymmetric/BPS conclusions from that source are assumed.

## 2. Global structure of the proposed worldsheet

### 2.1 Specify the spin lift

The preceding 14-multiplet spectrum consists of complex two-dimensional Weyl fermions:

|copies|chirality|color|normal SU2+|normal SU2-|x|z|
|---:|:---:|:---:|:---:|:---:|---:|---:|
|4|+|3|1|1|0|4|
|6|+|1|1|1|0|3|
|2|+|1|3|1|0|0|
|1|-|1|1|4|0|0|
|1|-|1|1|2|0|0|

The normal rotations and the sphere's geometric weak SU2 are different groups.

For an oriented rank-2 tangent plane plus a rank-4 normal plane in a spin six-manifold, the subgroup lifting SO(2) x SO(4) is

    H = [Spin(2) x Spin(4)] / <(-1,-1)>.

This follows directly from multiplication of the two even Clifford-algebra spin subgroups: the two scalar -1 elements map to the same -1 in Spin(6), so their pair maps to +1.

A two-dimensional spinor in a normal representation (j+,j-) has diagonal-kernel action

    (-1) * (-1)^[2j+ + 2j-].

It descends as an ordinary representation of H only if this action is +1. The normal singlets and triplets in the positive-chirality rows fail that test; the normal quartet and doublet pass. There are 24 complex components in the first group and 6 in the second.

This is NOT an inconsistency of an intrinsically spin worldsheet. It identifies extra data that cannot be omitted. Choosing a spin structure for TSigma and a compatible independent normal spin lift makes the table well-defined. An ambient spin structure alone fixes their combined quotient structure, not arbitrary independent lifts. A spin-structure sum/projection or a more elaborate refined defect could alter this conclusion and has not been constructed.

On the reference S2, H1(S2,Z2)=0, so the spin structure is unique. This explains why the earlier local sphere determinant did not expose the family-level lift issue. Odd tensor lattices and their need for additional global data are discussed in [2].

### 2.2 A degree-three bordism calculation for the lifted category

For the following result ONLY, fix a worldsheet spin structure and independent normal Spin(4) lift and use

    G_ws = SU(3)_C x U(1)_X x U(1)_Z x SU(2)_N+ x SU(2)_N-.

No center quotient, tensor higher-group background, or dynamical spin sum is included in this BG. Those are different anomaly problems.

The standard spin-bordism AHSS has

    E2_(p,q) = H_p(BG_ws; Omega_q^Spin(pt)),
    Omega_0^Spin=Z, Omega_1^Spin=Z2, Omega_2^Spin=Z2, Omega_3^Spin=0.

The relevant BG homology is torsion-free and even in these degrees. At total degree 3 the only possibly nonzero term is

    E2_(2,1)=H2(BG_ws;Z2)=Z2^2.

The incoming differential

    d2: H4(BG_ws;Z) -> H2(BG_ws;Z2)

is the homology dual of Sq2 after reduction mod 2. For the degree-2 first Chern generators,

    Sq2(x)=x^2,  Sq2(z)=z^2.

In the H4 basis dual to (x^2,xz,z^2,c2(C),c2(N+),c2(N-)), the map is

    [1 0 0 0 0 0]
    [0 0 1 0 0 0].

It is surjective. All total-degree-three entries are therefore zero on subsequent pages, with no extension problem. Consequently

    Omega_3^Spin(BG_ws)=0.

The differential and low-degree calculation method are established [3]. The new script verifies this finite differential matrix, not the spectral-sequence theorem itself.

### 2.3 Explicit inverse anomaly phase on the lifted category

The local anomaly has integral periods on closed spin four-manifolds with these bundles. Indeed write

    integral p1(TW)=48k,
    integral Z^2=2m,
    integral c2(N+)=n+,
    integral c2(N-)=n-,
    integral c2(C)=nC.

The first identity follows from signature plus Rokhlin; the second is evenness of the spin intersection form. Then

    integral I4rho = -36k -8n+ +11n- +246m -4nC,

an integer. It is also directly a sum of the corresponding complex Dirac index densities.

For a closed spin three-manifold Y with these lifted bundles, choose a spin filling W carrying extensions. Such a filling exists by the bordism result. The candidate inverse anomaly phase

    Z_inv(Y) = exp[-2 pi i integral_W I4rho]

is independent of the filling: changing W adds a closed spin four-manifold, on which the exponent changes by an integral multiple of 2 pi i. With a consistent descent sign, it supplies the inverse of the chiral fermion anomaly. The relation to eta invariants and anomaly inflow is standard [4].

Thus there is no additional flat/torsion anomaly in THIS ordinary lifted worldsheet background category after matching the local polynomial. This is not a vanishing claim for the uncanceled chiral determinant; it must be combined with its inverse anomaly theory.

Crucially, this does not prove that the six-dimensional odd-lattice Green--Schwarz theory supplies this inverse theory on actual embedded surfaces. The global tensor differential cocycles, their refinements, descent under changing spin lifts, operator statistics, and possible higher-group data are absent from this bordism computation. The distinction is central to global Green--Schwarz constructions [5]. No six-dimensional global-completion claim is made.

## 3. Can the charge be obtained from a smooth core of the existing fields?

### 3.1 Source-component difference

With no explicit string source, the charge induced by smooth gauge/gravitational densities is, up to an overall orientation convention,

    q_ind = integral_C4 S4.

Subtracting the two components eliminates both the gravitational and color sources:

    (S4)_1 - (S4)_2 = -X^2 + 9 Z^2.

The desired primitive charge has

    q_1-q_2 = -1.

These identities are independent of a kinetic-metric choice and of the local worldsheet anomaly cancellation.

### 3.2 A localized transverse R4 core

Test the ordinary instanton-string construction with a smooth transverse R4, asymptotics allowing the gauge bundles to extend across its one-point compactification S4, the stated direct-product group, and no extra singular sources or topology. Since H2(S4,Z)=0, the two Abelian line bundles are trivial and

    integral_S4 X^2 = integral_S4 Z^2 = 0.

Therefore q_ind has equal components. On the strict product tangent extension p1 integrates to zero as well, and a color instanton with number nC gives

    q_ind = nC vC = 4 nC (1,1).

No nonzero multiple of (9,10) lies on that line. A smooth SU3 instanton cannot provide the proposed primitive core with these source coefficients. Gauge instantons can resolve string cores in some richer six-dimensional models [6]; this calculation tests why the particular displayed color coupling cannot do so here.

This is a restricted topological obstruction, not a theorem excluding strings in the model. It does not cover a fundamental string, nontrivial transverse topology, non-cover gauge groups, new gauge sectors, additional tensor sources, or a core not described by the displayed smooth fields. No differential field equations have been solved merely by doing this source test.

### 3.3 Closed spin four-manifolds

More generally, for integral Abelian curvatures on a closed spin four-manifold, the Wu formula gives

    integral X^2 = 0 mod2,  integral Z^2 = 0 mod2.

Hence every charge induced by these smooth sources has even component difference. The primitive (9,10) charge fails this necessary condition. This does NOT say that exp(i rho) is forbidden or fermionic. It classifies charges induced by the specified smooth characteristic sources, not all allowed fundamental tensor charges.

The algebraic generator matrix for the smooth characteristic numbers is

    [2vX | 2vZ | vC | 12a].

Its Smith normal form has nonzero diagonal entries (2,2); as an arithmetic image it is 2 Z^2. This stronger statement uses the even Abelian squares and p1=48k. It is not an existence theorem for finite-action solitons.

A characteristic-class comparison is

    20vX + 2vZ + 71vC = (18,20) = 2q.

On S2 x S2, let h1,h2 be the standard degree-2 generators with h1^2=h2^2=0 and integral h1 h2=1. The classes X=h1+10h2 and Z=h1+h2 have squares 20 and 2. Taking c2(C)=71 and p1=0 produces the displayed double charge. This is only an arithmetic/topological certificate on a changed transverse manifold; no such background solution or instanton amplitude is claimed.

## 4. Strengthen the genus-zero fermion-kernel statement

The previous note assumed zero internal hypercharge field. This restriction can be relaxed for the minimally coupled free fermions in the table, as long as the total hypercharge flux is zero and color and normal twisting are still trivial.

On Sigma=CP1, the spin bundle is O(-1). Any smooth U1 connection defines a holomorphic structure on its line bundle, because on a complex curve its (0,2) curvature vanishes automatically. Every degree-zero holomorphic line bundle on CP1 is isomorphic to O(0). Thus for any integer charge z the chiral spinor bundle is holomorphically O(-1), and

    H0(CP1,O(-1))=0,
    H1(CP1,O(-1))=0.

There is neither a kernel nor a cokernel. This uses the actual holomorphic Dirac problem, not only its zero index. The relation between sphere Dirac zero modes and holomorphic sections is explained in [7].

The same conclusion can be seen directly for the previous dipole. Write

    A_Z = kappa sin^2(theta) dphi = *d psi,
    psi=-kappa cos(theta).

The flux integrates to zero. With D=d-i z A and consistent complex-coordinate conventions,

    dbar_A = exp(-z psi) dbar_0 exp(z psi).

Multiplication by the smooth nowhere-zero exponential maps the chiral kernels isomorphically. It does not preserve eigenvalues or determinant magnitude, but it preserves the zero-kernel property. No small-kappa assumption is needed for this mathematical kernel result.

All the proposed defect fermions have x=0, so the background X monopole does not twist them. Smooth hypercharge dipole backreaction alone therefore does not generate fermion zero modes in this stipulated sector. This extends the previous free round-reference conclusion.

This result does not apply to arbitrary non-Abelian normal/color connections, added core fermions, mass or Pauli interactions, singular gauge fields, or changes of genus. A topologically trivial non-Abelian vector bundle may split holomorphically as O(k) plus O(-k), unlike a single degree-zero line bundle. The determinant magnitude and complete defect amplitude remain uncomputed.

## 5. The universal exterior is calculable, but it is not the core

### 5.1 Four-dimensional low-energy regime

Use the physical angles theta=(u,rho) with a constant positive kinetic matrix K in a four-dimensional Euclidean annulus. This is appropriate only if all distances in that annulus are above the inverse heavy thresholds needed for this effective description and below the relevant light phase Compton wavelengths. It is not a solution of the fully sourced six-dimensional Einstein equations.

The quadratic action is

    S0 = (1/2) integral K_ab dtheta^a wedge *dtheta^b.

The insertion exp(i rho(0)) has character covector n=(0,1). Separate the constant background phase theta_infinity, rather than integrating it away while computing an effective-potential coefficient. The insertion modifies the Gaussian exponent by +i n.theta(0).

The saddle equation is

    -K_ab Laplacian theta^b = i n_a delta4(x).

The R4 Green function is G(R)=1/(4 pi^2 R^2), with -Laplacian G=delta4. Therefore the complex scalar saddle is

    theta(R)=theta_infinity+i K^-1 n/(4 pi^2 R^2).

The imaginary Euclidean displacement is required by the insertion. A real harmonic scalar sourced by a real charge is not the same path-integral saddle. It must be interpreted with the source/boundary terms or equivalently with the real fixed-flux dual description.

With K=[[Kuu,Kurho],[Kurho,Krhorho]], the profile can excite u as well as rho:

    theta-theta_infinity
       = i(-Kurho,Kuu)^T /[4 pi^2 R^2 det K].

A potential depending on rho alone need not have a purely rho exterior when kinetic mixing is present.

### 5.2 Flux and regulated self-action

Normalize dual three-forms by

    H_a=i K_ab *dtheta^b,
    integral_S3 H_a=n_a.

No 2 pi is included in this particular dual-flux convention. Then H is real on the displayed saddle, and on the annulus

    H_a=(n_a/2 pi^2) vol_unit(S3).

The positive dual kinetic action gives

    S_ext(eps,L)
       = [n^T K^-1 n/(8 pi^2)] (eps^-2-L^-2).

Define

    f_rho^-2 = (K^-1)_(rho rho).

The correct coefficient uses the inverse matrix. In general it is NOT 1/K_(rho rho). The shell action is positive for 0<eps<L and K positive.

The formal eps -> 0 behavior is quadratic in the cutoff. That limit is outside the four-dimensional approximation once eps crosses a heavy threshold. It is not proof that the physical amplitude vanishes or that the full six-dimensional string has infinite renormalized action. It proves that the area term alone is not the full regulated action and that the exterior cannot supply the missing core normalization.

### 5.3 Matching, rather than declaring an arbitrary mass

Let mu=1/eps and mu_IR=1/L, and define c=(K^-1)_(rho rho)/(8 pi^2). In a scheme where the core coefficient excludes this Gaussian shell,

    A_physical = A_core(mu) exp[-c(mu^2-mu_IR^2)].

At fixed K, matching-scale independence imposes

    d log A_core/dmu = 2c mu.

It determines the running in this approximation, not the integration constant. A tension, core determinant, allowed spin-refined insertion, and additional fields can affect that constant. If the defect does not exist or a selection rule sets the amplitude to zero, this formal matching formula does not manufacture a nonzero answer.

A mass or string tension cannot be computed from the indefinite lattice norm -19. As a limited illustration, a positive determinant-one O(1,1)-compatible energy metric can be written with y>0 as

    G(y) = (1/2) [[y+1/y,y-1/y],[y-1/y,y+1/y]].

It obeys G Omega G=Omega and

    q^T G q = (361 y+1/y)/2
            = 19 + (19y-1)^2/(2y) >= 19.

This is a positive energy-metric identity, not a BPS bound, not a calculated tension, and not a claim that the model includes a modulus y with this vacuum value. It simply shows explicitly why a negative topological norm is not negative kinetic energy.

## 6. Research consequences

1. With chosen independent spin lifts and the direct-product group, the proposed worldsheet determinant has a globally definable inverse anomaly theory. This is a conditional advance in the worldsheet sector, not a global six-dimensional completion.
2. The table needs those spin data (or another justified descent mechanism). A polynomial anomaly match does not supply them automatically.
3. The primitive neutral tensor charge is not a smooth gauge-instanton source of the existing fields on the original transverse R4 class. A new microscopic source or changed topology/gauge structure must be specified.
4. The degree-zero Abelian dipole does not, by itself, create the feared fermion kernel on S2. This is a stronger no-kernel result than in the preceding note, with color and normal twisting still restricted.
5. The exterior field and cutoff dependence are computable. They do not determine the finite core coefficient, prove a nonzero rho potential, or solve the fully sourced metric equations.

The original T-1 electromagnetic-normalization problem is unaffected. None of these calculations fixes a Maxwell kinetic coefficient or derives the measured fine-structure constant. No claimed current physical result is imported from the corpus's superseded historical sections.

## References and exact role

[1] H. Shimizu and Y. Tachikawa, "Anomaly of strings of 6d N=(1,0) theories," arXiv:1608.05894. Local string source/self-intersection inflow only; no supersymmetric spectrum or BPS condition imported. https://arxiv.org/html/1608.05894

[2] N. Seiberg and W. Taylor, "Charge Lattices and Consistency of 6D Supergravity," arXiv:1103.0019. Odd/even tensor charge lattices and global data; not an existence theorem for our primitive string. https://arxiv.org/html/1103.0019

[3] J. Davighi, B. Gripaios and N. Lohitsiri, "Global anomalies in the Standard Model(s) and Beyond," arXiv:1910.11277. Spin-bordism AHSS, Sq2 differentials, and the analogous degree-three calculation. The enlarged product-group calculation here is derived in Section 2. https://arxiv.org/html/1910.11277

[4] E. Witten and K. Yonekura, "Anomaly Inflow and the eta-Invariant," arXiv:1909.08775. Relation of fermion global anomalies, index density, and inverse inflow phases. https://arxiv.org/abs/1909.08775

[5] S. Monnier and G. W. Moore, "Remarks on the Green--Schwarz Terms of Six-Dimensional Supergravity Theories," arXiv:1808.01334. Global tensor/refinement requirements. Its sufficient full-theory hypotheses have not been verified for this trial. https://arxiv.org/html/1808.01334

[6] M. J. Duff, H. Lu and C. N. Pope, "Heterotic phase transitions and singularities of the gauge dyonic string," arXiv:hep-th/9603037. Prior example of transverse gauge-instanton string sources in a different theory. Bibliographic abstract consulted; no full solution imported. https://arxiv.org/abs/hep-th/9603037

[7] R. Jante and B. J. Schroers, "Dirac operators on the Taub-NUT space, monopoles and SU(2) representations," arXiv:1312.4879. Sphere Dirac kernel and holomorphic sections. The degree-zero deformation extension here is a line-bundle argument, not a quotation of an invariant-monopole formula. https://arxiv.org/html/1312.4879

[8] S. Monnier, G. W. Moore and D. S. Park, "Quantization of anomaly coefficients in 6D N=(1,0) supergravity," arXiv:1711.04777. Characteristic tensor sources and quantization conventions. https://arxiv.org/html/1711.04777

[9] J. Lin, "Pin(2)-equivariant KO-theory and intersection forms of spin four-manifolds," arXiv:1401.3264. Standard spin intersection-form and signature context; no improved inequality is needed in this calculation. https://arxiv.org/html/1401.3264

The project compilation's claim-by-claim change log, visible in this conversation as turn45file1, distinguishes the illustrative compactification from the corpus action (lines 549-558) and keeps T-1 classified as a gated geometric candidate (lines 64-78). The archive section audit inserts also reserve current technical authority to Part 0 rather than superseded historical claims.
