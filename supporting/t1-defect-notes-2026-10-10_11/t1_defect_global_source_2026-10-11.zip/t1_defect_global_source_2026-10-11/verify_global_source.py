#!/usr/bin/env python3
"""Finite algebra checks for a CONDITIONAL defect/global-source calculation.

This script checks representations, AHSS matrices conditional on the standard
spin-bordism input, characteristic-number arithmetic, and an exterior Gaussian
solution. It does NOT establish a microscopic string, a six-dimensional global
Green--Schwarz theory, a resolved core, or a nonzero instanton amplitude.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import sympy as s
from sympy.matrices.normalforms import smith_normal_form

R = s.Rational
checks: dict[str, bool] = {}

def eq(name: str, residual: object) -> None:
    if name in checks:
        raise ValueError(f'duplicate check {name}')
    vals = list(residual) if isinstance(residual, s.MatrixBase) else [residual]
    red = [s.simplify(s.expand(s.sympify(v))) for v in vals]
    checks[name] = all(v == 0 for v in red)
    if not checks[name]:
        raise AssertionError(f'{name}: {red}')

def test(name: str, value: object) -> None:
    if name in checks:
        raise ValueError(f'duplicate check {name}')
    checks[name] = bool(value)
    if not checks[name]:
        raise AssertionError(name)

O = s.diag(1,-1)
q = s.Matrix([9,10])
a = s.Matrix([3,3])
vX = s.Matrix([-10,-9])
vZ = s.Matrix([-33,-42])
vC = s.Matrix([4,4])
beta,gamma,alpha = s.symbols('beta gamma alpha', real=True)
phi = s.Matrix([-beta/2-gamma,beta/2-gamma])
p1,pT,X,Z,cC,cP,cM = s.symbols('p1 p1T X Z c2C c2Nplus c2Nminus')
source = a*p1/4 + vX*X**2 + vZ*Z**2 + vC*cC
pair = lambda x,y: (x.T*O*y)[0]
eq('inherited_defect_character',pair(q,phi)-(gamma-R(19,2)*beta))
eq('inherited_X_neutrality',pair(q,2*vX))
eq('inherited_odd_norm',pair(q,q)+19)
eq('inherited_gravitational_pairing',pair(q,a)+3)
eq('inherited_Z_pairing',pair(q,vZ)-123)
eq('inherited_color_pairing',pair(q,vC)+4)
I4 = s.expand((pair(q,source)+pair(q,q)*(cP-cM)/2).subs(p1,pT-2*(cP+cM)))
target = -R(3,4)*pT-8*cP+11*cM+123*Z**2-4*cC
eq('inherited_full_inflow',I4-target)

@dataclass(frozen=True)
class F:
    copies:int; chir:int; color:int; dp:int; dm:int; z:int
    @property
    def dim(self)->int: return self.color*self.dp*self.dm
    @property
    def normal_center(self)->int: return (-1)**((self.dp-1)+(self.dm-1))
    @property
    def diagonal_kernel(self)->int: return -self.normal_center

fields=[F(4,1,3,1,1,4),F(6,1,1,1,1,3),F(2,1,1,3,1,0),F(1,-1,1,1,4,0),F(1,-1,1,1,2,0)]
index2=lambda d:R(d*(d*d-1),6)
I4ferm=0
for f in fields:
    piece=f.dim*(f.z**2*Z**2/2-pT/24)
    if f.color==3: piece-=f.dp*f.dm*cC
    piece-=f.color*f.dm*index2(f.dp)*cP+f.color*f.dp*index2(f.dm)*cM
    I4ferm+=f.copies*f.chir*piece
eq('worldsheet_anomaly_reconstruction',I4ferm-target)
eq('worldsheet_signed_dimension',sum(f.copies*f.chir*f.dim for f in fields)-18)
eq('worldsheet_total_dimension',sum(f.copies*f.dim for f in fields)-30)
# Spin(2)xSpin(4) -> Spin(6) has diagonal (-1,-1) kernel.
for j,f in enumerate(fields):
    eq(f'spin_descent_row_{j+1}',f.diagonal_kernel-([-1,-1,-1,1,1][j]))
eq('components_requiring_separate_spin_lift',sum(f.copies*f.dim for f in fields if f.diagonal_kernel==-1)-24)
eq('components_descending_at_representation_level',sum(f.copies*f.dim for f in fields if f.diagonal_kernel==1)-6)

# Standard AHSS input, not machine-proved topology:
# Omega_q^Spin(pt) for q<=3: Z,Z2,Z2,0; BG has no odd H_i here.
# H2(BG)=Z^2 and H4(BG)=Z^6 for G=U1X x U1Z x SU3 x SU2+ x SU2-.
# d2_{4,0} is dual Sq^2 after mod2. Squares of c1X/c1Z span H2 mod2.
d2=s.Matrix([[1,0,0,0,0,0],[0,0,1,0,0,0]])
eq('AHSS_source_target_shape_rows',d2.rows-2)
eq('AHSS_source_target_shape_cols',d2.cols-6)
eq('AHSS_surjective_minor',d2[:,[0,2]]-s.eye(2))
images={tuple(int(z)%2 for z in d2*s.Matrix([(b>>i)&1 for i in range(6)])) for b in range(64)}
test('AHSS_image_is_all_H2_mod2',images=={(0,0),(1,0),(0,1),(1,1)})
eq('AHSS_degree3_remaining_dimension',2-2)
# Evaluation of the local polynomial on CLOSED SPIN four-manifolds:
# int p1=48k; int Z^2=2m. The two c2(N)'s and c2(C) are integral.
k,m,nP,nM,nC=s.symbols('k m nP nM nC',integer=True)
period=-R(3,4)*48*k-8*nP+11*nM+123*2*m-4*nC
eq('spin_filling_polynomial_integral_form',period-(-36*k-8*nP+11*nM+246*m-4*nC))
test('spin_filling_has_integer_coefficients',all(c.is_Integer for c in s.Poly(period,k,m,nP,nM,nC).coeffs()))

# Robust genus-zero Abelian kernel test. Holomorphic line degree n determines
# h0(O(n-1)),h1(O(n-1)); only the arithmetic is checked here.
def cohom(n:int)->tuple[int,int]: return max(n,0),max(-n,0)
test('CP1_degree_zero_kernel_and_cokernel',cohom(0)==(0,0))
eq('all_proposed_components_degree_zero',sum(f.copies*f.dim*sum(cohom(0)) for f in fields))
theta,kap,zq=s.symbols('theta kappa zq', real=True)
psi=-kap*s.cos(theta)
Aphi=kap*s.sin(theta)**2
# On the oriented round sphere *(d psi) = psi' sin(theta) dphi.
eq('dipole_is_coexact',s.diff(psi,theta)*s.sin(theta)-Aphi)
flux=s.integrate(s.diff(Aphi,theta),(theta,0,s.pi))*2*s.pi
eq('dipole_total_flux_zero',flux)
# Chiral factorization: dbar_A=e^(-z psi) dbar e^(z psi), for A=*dpsi.
t=s.symbols('t',real=True)
h=s.Function('h')(t); pp=s.Function('psi')(t)
eq('chiral_complex_gauge_conjugation',s.exp(-zq*pp)*s.diff(s.exp(zq*pp)*h,t)-(s.diff(h,t)+zq*s.diff(pp,t)*h))

# Necessary topological source constraints.
eq('source_component_difference',source[0]-source[1]-(-X**2+9*Z**2))
eq('primitive_charge_component_difference',q[0]-q[1]+1)
NX,NZ,NC,P=s.symbols('NX NZ NC P',integer=True)
induced=vX*NX+vZ*NZ+vC*NC+a*P/4
eq('induced_charge_difference',induced[0]-induced[1]-(-NX+9*NZ))
eq('R4_one_point_compactification_equal_components',(induced[0]-induced[1]).subs({NX:0,NZ:0}))
eq('color_instanton_charge_line',induced.subs({NX:0,NZ:0,P:0})-s.Matrix([4*NC,4*NC]))
xn,zn=s.symbols('xn zn',integer=True)
eq('closed_spin_difference_even',(induced[0]-induced[1]).subs({NX:2*xn,NZ:2*zn})-2*(-xn+9*zn))
# Algebraic span of allowed characteristic-number source columns. This is NOT
# an existence proof for finite-action solutions realizing arbitrary columns.
cols=s.Matrix.hstack(2*vX,2*vZ,vC,12*a)
smith=smith_normal_form(cols,domain=s.ZZ)
eq('smooth_spin_source_Smith_first',abs(smith[0,0])-2)
eq('smooth_spin_source_Smith_second',abs(smith[1,1])-2)
eq('double_charge_characteristic_number_example',20*vX+2*vZ+71*vC-2*q)
# On S2xS2: (h1+10h2)^2=20; (h1+h2)^2=2; p1=0.
eq('S2xS2_X_square',2*1*10-20)
eq('S2xS2_Z_square',2*1*1-2)

# Universal FOUR-DIMENSIONAL exterior: theta=(u,rho), insertion exp(i rho).
# The positive kinetic matrix is NOT the odd tensor lattice pairing.
r,eps,L=s.symbols('R eps L',positive=True)
ka,kb,kc=s.symbols('Kuu Kurho Krhorho',real=True)
K=s.Matrix([[ka,kb],[kb,kc]])
Ki=K.inv(); nv=s.Matrix([0,1]); Dk=ka*kc-kb**2
f_inv=(nv.T*Ki*nv)[0]
eq('effective_inverse_decay_constant',f_inv-ka/Dk)
Green=1/(4*s.pi**2*r**2)
eq('Green_radial_harmonic_away_from_source',s.diff(Green,r,2)+3*s.diff(Green,r)/r)
eq('Green_unit_delta_flux',-2*s.pi**2*r**3*s.diff(Green,r)-1)
profile=s.I*Ki*nv*Green
eq('exterior_kinetic_mixing_profile',profile-s.I*s.Matrix([-kb,ka])*Green/Dk)
# With dual H=i K *dtheta, flux integral is n (no 2pi in this convention).
eq('real_dual_flux',s.I*K*s.diff(profile,r)*2*s.pi**2*r**3-nv)
radial_density=f_inv/(4*s.pi**2*r**3)
Sout=s.integrate(radial_density,(r,eps,L))
eq('exterior_fixed_flux_action',Sout-f_inv*(1/eps**2-1/L**2)/(8*s.pi**2))
eq('exterior_positive_shell_derivative',s.diff(Sout,eps)+f_inv/(4*s.pi**2*eps**3))
ratio=s.symbols('ratio',positive=True)
eq('exterior_action_matches_surface_term',Sout-s.Rational(1,2)*f_inv*(Green.subs(r,eps)-Green.subs(r,L)))
# Wilsonian coefficient: Aphys=Acore(mu)*exp[-c(mu^2-muIR^2)].
mu,muIR,c=s.symbols('mu muIR c',positive=True)
shell=c*(mu**2-muIR**2)
eq('core_matching_log_derivative',s.diff(shell,mu)-2*c*mu)
# A COMPATIBLE O(1,1) kinetic-metric illustration only: no tension predicted.
y=s.symbols('y',positive=True)
G=s.Matrix([[(y+1/y)/2,(y-1/y)/2],[(y-1/y)/2,(y+1/y)/2]])
eq('illustrative_tensor_metric_compatibility',G*O*G-O)
eq('illustrative_positive_tensor_metric_det',G.det()-1)
energy=(q.T*G*q)[0]
eq('charge_metric_energy_expression',energy-(361*y+1/y)/2)
eq('charge_metric_energy_positive_bound_identity',energy-19-(19*y-1)**2/(2*y))
eq('charge_metric_energy_minimum',energy.subs(y,R(1,19))-19)

out={
 'date':'2026-10-11',
 'status':'CONDITIONAL GLOBAL-WORLDSHEET AND SMOOTH-SOURCE/EXTERIOR CALCULATIONS; NO MICROSCOPIC DEFECT COMPLETION',
 'checks_passed':len(checks), 'checks':checks,'sympy_version':s.__version__,
 'global_background_category':'Chosen worldsheet spin structure and compatible independent Spin(4) normal lift; direct-product SU3 x U1X x U1Z gauge group.',
 'AHSS_standard_input_is_not_machine_proved':True,
 'conditional_spin_bordism_degree_3':0,
 'worldsheet_components_not_descending_from_ambient_spin_alone':24,
 'local_source_difference':'-X^2+9 Z^2',
 'R4_smooth_color_source_charge':'4 n (1,1), with other displayed bundles topologically trivial',
 'closed_spin_source_algebraic_image':'2 Z^2',
 'closed_spin_example_for_double_charge':{'integral_X_squared':20,'integral_Z_squared':2,'color_c2':71,'p1':0,'induced_charge':[18,20]},
 'nozero_statement':'On genus zero, a smooth U1 degree-zero connection alone cannot produce a Dirac zero mode for this spin bundle; flat color and normal connections remain assumed.',
 'exterior_action':'[(K^-1)_{rho rho}/(8 pi^2)] (eps^-2-L^-2)',
 'negative_claims':{
   'full_6D_global_GS_path_integral_constructed':False,
   'ambient_spin_only_worldsheet_descent_established':False,
   'microscopic_dynamical_string_constructed':False,
   'smooth_R4_gauge_core_carries_primitive_charge':False,
   'Einstein_equations_solved_with_core':False,
   'finite_renormalized_defect_action_computed':False,
   'nonzero_vacuum_coefficient_proved':False,
   'measured_alpha_derived':False},
 'scope_notes':['AHSS rank check is conditional on the stated standard topology input.',
   'A counterterm for the lifted worldsheet anomaly is not a proof that the bulk tensor theory supplies it.',
   'Even smooth-source charges on closed spin four-manifolds do not forbid odd fundamental string charges.',
   'The regulated four-dimensional exterior must not be extrapolated below its cutoff.',
   'The O(1,1) illustration is an energy-metric identity, not a BPS or tension formula.']}
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_name('global_source_results.json'))
args=p.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(out,indent=2)+'\n')
print(f'{len(checks)} exact finite-algebra checks passed.')
print('Lifted spin worldsheet: degree-three bordism obstruction vanishes with the specified standard inputs.')
print('Primitive (9,10) charge is not generated by the specified smooth R4 gauge/gravity source class.')
print('Degree-zero Abelian sphere twisting does not force a kernel; scalar exterior has positive regulated self-action.')
print('No globally completed six-dimensional defect, core, nonzero vacuum amplitude, or alpha prediction established.')
