# T-1 exploratory defect: global/source follow-up

Read `RESEARCH_NOTE.md` for assumptions, derivations, and limitations.

Run:

```sh
python -m pip install -r requirements.txt
python verify_global_source.py --output fresh_results.json
```

The new script contains 54 finite-algebra checks. Its topological conclusions use explicitly stated standard spin-bordism and characteristic-class inputs; these inputs are not machine-proved by the script. The included baseline is the preceding wrapped-defect archive with a fresh 50-check rerun.

No new empirical data, measured alpha input, microscopic string, resolved core, six-dimensional global counterterm, nonzero vacuum amplitude, or physical pseudoscalar mass is established.

The four-copy odd-lattice sphere model remains an illustrative extension, not an identified part of the original toroidal action. An auxiliary inverse worldsheet anomaly theory on chosen spin lifts is not a full global tensor theory.
